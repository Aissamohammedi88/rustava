#!/usr/bin/env bash
# RUSTAVA — installation en une commande
# Tout est déjà dans ce dossier (binaire compilé + runtime + exemples) :
# ce script vérifie gcc et pose le compilateur dans ~/.local/bin.
set -u
DIR=$(cd "$(dirname "$0")" && pwd)

echo "==> 1/3 : vérification de gcc (le moteur C de Rustava)..."
if command -v cc >/dev/null 2>&1 ; then
    echo "    gcc trouvé : $(cc --version | head -1)"
elif command -v gcc >/dev/null 2>&1 ; then
    echo "    gcc trouvé : $(gcc --version | head -1)"
else
    echo "[!] gcc est absent : Rustava compile vers du C, il lui faut gcc."
    echo "    Installe-le puis relance :  sudo apt install build-essential"
    exit 1
fi

echo "==> 2/3 : pose du compilateur dans ~/.local/bin ..."
if [[ ! -x "$DIR/rustava" ]] ; then
    echo "[!] $DIR/rustava est introuvable — es-tu bien dans le dossier décompressé ?"
    exit 1
fi
mkdir -p "$HOME/.local/bin"
cp "$DIR/rustava" "$HOME/.local/bin/rustava"
chmod +x "$HOME/.local/bin/rustava"
# le runtime C, à côté du binaire ET dans ~/.local/share/rustava (double filet)
mkdir -p "$HOME/.local/share/rustava/src"
cp "$DIR/src/runtime.h" "$HOME/.local/share/rustava/runtime.h"
cp "$DIR/src/runtime.h" "$HOME/.local/share/rustava/src/runtime.h"

echo "==> 3/3 : test de santé..."
(cd "$DIR" && ./rustava run exemples/nexus.rv) || {
    echo "[!] le test a échoué — écris-moi le message ci-dessus"
    exit 1
}

echo
echo "✓ RUSTAVA installé. Trois façons de l'utiliser :"
echo "   1) dans ce dossier   : ./rustava run exemples/nexus.rv"
echo "   2) depuis ton home   : ~/.local/bin/rustava run ~/mes-code/nexus.rv"
echo "   3) si ~/.local/bin est dans ton PATH : rustava run nexus.rv"
echo
echo "   Vérifie ton PATH si le 3 ne marche pas :"
echo "     echo \$PATH | grep -q \"\$HOME/.local/bin\" && echo OK || echo 'ajoute-le dans ~/.bashrc'"
echo "   Et la preuve que tout va bien :"
echo "     bash tests/regression.sh"
