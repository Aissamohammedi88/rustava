// ------------------------------------------------------------
// RUSTAVA — le compilateur (CLI)
//
//   rustava run   fichier.rv     compile + exécute
//   rustava build fichier.rv     produit un binaire natif
//   rustava check  fichier.rv     vérifie sans produire rien
//   rustava c     fichier.rv     montre le C généré (curiosité)
//
// Les 4 étapes : Lexer → Parser → Type Checker → Code Generator (C)
// ------------------------------------------------------------

mod ast;
mod checker;
mod codegen;
mod lexer;
mod parser;

use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

fn banniere() {
    println!("RUSTAVA 1.0 — le mariage Java × Rust");
    println!("  forme de Java (classes, accolades, ;) + mémoire de Rust (let/var)");
    println!("  zéro ramasse-miettes — binaire natif via C");
}

fn aide() {
    banniere();
    println!();
    println!("Utilisation :");
    println!("  rustava run   programme.rv    compile et exécute");
    println!("  rustava build programme.rv    produit l'exécutable « programme »");
    println!("  rustava check programme.rv    vérifie seulement (rien n'est produit)");
    println!("  rustava c     programme.rv    affiche le C généré");
    println!("  rustava aide                  ce message");
}

fn rattrape_chemin(arg: &str) -> PathBuf {
    let p = Path::new(arg);
    if p.exists() {
        p.to_path_buf()
    } else if let Ok(cwd) = env::current_dir() {
        let q = cwd.join(arg);
        if q.exists() {
            q
        } else {
            p.to_path_buf()
        }
    } else {
        p.to_path_buf()
    }
}

fn compile_vers_c(fichier: &Path) -> Result<String, String> {
    let src = match fs::read_to_string(fichier) {
        Ok(s) => s,
        Err(e) => {
            return Err(format!(
                "impossible de lire « {} » : {}",
                fichier.display(),
                e
            ))
        }
    };

    // 1. LEXER
    let toks = match lexer::lexer(&src) {
        Ok(t) => t,
        Err(e) => {
            return Err(format!(
                "Erreur de syntaxe (ligne {}, colonne {}) : {}",
                e.line, e.col, e.msg
            ))
        }
    };

    // 2. PARSER
    let mut p = parser::Parser::new(toks);
    let prog = match p.programme() {
        Ok(pr) => pr,
        Err(e) => return Err(format!("Erreur de syntaxe (ligne {}) : {}", e.line, e.msg)),
    };

    // 3. TYPE CHECKER (et borrow checker simplifié)
    let mut ck = checker::Checker::new(&prog);
    if let Err(e) = ck.verifier_tout() {
        return Err(format!("Erreur de type (ligne {}) : {}", e.line, e.msg));
    }

    // 4. CODE GENERATOR (C)
    Ok(codegen::Gen::new(&prog).generer())
}

fn chemin_runtime() -> Result<PathBuf, String> {
    // ordre de recherche du runtime C :
    //   1. à côté de l'exécutable (livraison décompressée : ./rustava + ./src/runtime.h)
    //   2. ~/.local/share/rustava (pose par installe.sh)
    //   3. le dossier courant (src/runtime.h ou runtime.h)
    let mut candidats = vec![
        env::current_exe()
            .map(|p| p.parent().map(|q| q.join("runtime.h")).unwrap_or_default())
            .unwrap_or_default(),
        env::current_exe()
            .map(|p| {
                p.parent()
                    .map(|q| q.join("src").join("runtime.h"))
                    .unwrap_or_default()
            })
            .unwrap_or_default(),
    ];
    if let Ok(home) = env::var("HOME") {
        let h = PathBuf::from(&home);
        candidats.push(h.join(".local/share/rustava/runtime.h"));
        candidats.push(h.join(".local/share/rustava/src/runtime.h"));
    }
    candidats.push(PathBuf::from("runtime.h"));
    if let Ok(cwd) = env::current_dir() {
        candidats.push(cwd.join("src/runtime.h"));
        candidats.push(cwd.join("runtime.h"));
    }
    for c in candidats {
        if c.exists() {
            return Ok(c);
        }
    }
    Err("je ne trouve pas runtime.h (le cœur C de Rustava) : garde le dossier src/ à côté du binaire, ou relance installe.sh".into())
}

fn vers_binaire(fichier: &Path, c_code: &str) -> Result<PathBuf, String> {
    // on absolutise d'abord : sinon « rustava run nexus.rv » chercherait
    // l'exécutable « nexus » dans le PATH au lieu du dossier courant
    let fichier = fichier
        .canonicalize()
        .unwrap_or_else(|_| std::env::current_dir().unwrap_or_default().join(fichier));
    let base = fichier.file_stem().unwrap_or_default().to_string_lossy().to_string();
    let dir = fichier.parent().unwrap_or(Path::new(".")).to_path_buf();
    let c_path = dir.join(format!("{}.c", base));
    let out_path = dir.join(&base);

    if fs::write(&c_path, c_code).is_err() {
        return Err(format!("impossible d'écrire « {} »", c_path.display()));
    }

    let runtime = chemin_runtime()?;
    let incl = runtime
        .parent()
        .map(|p| p.to_path_buf())
        .unwrap_or_else(|| PathBuf::from("."));

    // gcc : binaire natif, -O2, liens pthread (pour spawn)
    let statut = Command::new("cc")
        .arg("-O2")
        .arg("-std=c11")
        .arg("-I")
        .arg(&incl)
        .arg("-o")
        .arg(&out_path)
        .arg(&c_path)
        .arg("-lpthread")
        .arg("-lm")
        .status()
        .map_err(|e| format!("impossible de lancer cc (gcc) : {}", e))?;

    if !statut.success() {
        return Err(format!(
            "la compilation C a échoué — regarde {}",
            c_path.display()
        ));
    }

    Ok(out_path)
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 {
        aide();
        return;
    }
    let cmd = args[1].clone();
    match cmd.as_str() {
        "aide" | "--aide" | "-h" | "--help" => aide(),
        _ => {
            if args.len() < 3 {
                println!("il manque le nom du fichier .rv");
                println!();
                aide();
                return;
            }
            let fichier = rattrape_chemin(&args[2]);
            match cmd.as_str() {
                "c" => match compile_vers_c(&fichier) {
                    Ok(c) => println!("{}", c),
                    Err(e) => {
                        eprintln!("{}", e);
                        std::process::exit(1);
                    }
                },
                "check" => match compile_vers_c(&fichier) {
                    Ok(_) => println!("✓ tout est cohérent (syntaxe, types, mémoire)"),
                    Err(e) => {
                        eprintln!("{}", e);
                        std::process::exit(1);
                    }
                },
                "build" => match compile_vers_c(&fichier) {
                    Ok(c) => match vers_binaire(&fichier, &c) {
                        Ok(b) => println!("✓ binaire natif : {}", b.display()),
                        Err(e) => {
                            eprintln!("{}", e);
                            std::process::exit(1);
                        }
                    },
                    Err(e) => {
                        eprintln!("{}", e);
                        std::process::exit(1);
                    }
                },
                "run" => match compile_vers_c(&fichier) {
                    Ok(c) => {
                        let b = vers_binaire(&fichier, &c).unwrap_or_else(|e| {
                            eprintln!("{}", e);
                            std::process::exit(1);
                        });
                        let statut = Command::new(&b).status().unwrap_or_else(|e| {
                            eprintln!("impossible d'exécuter {} : {}", b.display(), e);
                            std::process::exit(1);
                        });
                        if !statut.success() {
                            std::process::exit(statut.code().unwrap_or(1));
                        }
                    }
                    Err(e) => {
                        eprintln!("{}", e);
                        std::process::exit(1);
                    }
                },
                _ => {
                    println!("commande inconnue « {} »", cmd);
                    aide();
                }
            }
        }
    }
}
