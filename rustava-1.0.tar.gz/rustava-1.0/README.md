# RUSTAVA — Le Mariage

> **RUSTAVA** = la forme de **Java** + la sécurité de **Rust**, cousues main dans un compilateur de 4 étapes.
> Ce dépôt contient le compilateur complet, écrit en Rust, qui produit du **C natif** — puis un binaire avec gcc.

```
       ┌─────────────────────────────────────────────────────────────┐
       │                     RUSTAVA (Le Langage)                    │
       └─────────────────────────────────────────────────────────────┘
                                     │
             ┌───────────────────────┴───────────────────────┐
             ▼                                               ▼
       ┌──────────────┐                               ┌──────────────┐
       │     JAVA     │                               │     RUST     │
       │  (La Forme)  │                               │ (La Sécurité)│
       └──────┬───────┘                               └──────┬───────┘
              │                                              │
              ▼                                              ▼
       • Classes, Interfaces                          • let (immuable)
       • try / catch                                  • var (mutable)
       • Accolades et points-virgules                 • match
       • Héritage refusé → implements                  • zéro GC
```

## Les règles du mariage (ce qu'on garde, ce qu'on jette)

| Concept | Java | Rust | **Rustava** (décision) |
| - | - | - | - |
| Variables mutables | `int x = 10;` | `let mut x = 10;` | **`var x = 10;`** (simple) |
| Variables immuables | inexistant | `let x = 10;` | **`let x = 10;`** (comme Rust) |
| Propriété mémoire | Garbage Collector (gèle) | Borrow Checker (complexe) | **Arène déterministe** — le compilateur gère, l'utilisateur ne se bat pas |
| Classes | `class Nexus {}` | inexistant | **`class Nexus {}`** (comme Java) |
| Fonctions | `void main()` | `fn main()` | **`fn main()`** (comme Rust, plus court) |
| Gestion d'erreur | try / catch | `Result<T, E>` | **try / catch** (comme Java, plus lisible) |
| Concurrence | Threads lourds | async / await | **`spawn`** (léger, détaché) |
| Héritage | `extends` | composition | **`implements`** uniquement — le `extends` est REFUSÉ avec un message gentil |

## L'ajustement critique : le « Borrow Checker » simplifié

Le compilateur **infère les propriétés à la place du développeur** :

1. **Les types sont vérifiés avant l'exécution** (3e étape du compilateur) — `let` immuable, pas de mélange `int`/`float`, tableaux homogènes, contrats d'interfaces complets.
2. **`borrow` existe mais est optionnel** — le compilateur emprunte tout seul lors des passages de fonctions.
3. **La mémoire vit dans une arène** : tout est alloué dans un bloc unique, **rendu d'un coup à la fin** (atexit). Aucun ramasse-miettes, aucune pause, aucune gelée : c'est ce qui remplace le GC Java.

```rustava
// Exemple de code Rustava (l'exemple Nexus du créateur)
class Nexus {
    fn main() {
        let nom = "Aissa";     // immuable
        var age = 30;          // mutable

        afficher(nom);         // passage par référence automatique
        age = age + 1;         // le compilateur gère la mémoire ici
    }
    fn afficher(texte: string) { print(texte); }
}

fn main() {
    let n = new Nexus();
    n.main();
}
```

## Le compilateur (les 4 étapes)

Écrit en **Rust pur** (zéro dépendance externe), dans `src/` :

| Étape | Fichier | Rôle |
| - | - | - |
| 1. Lexer | `lexer.rs` | découpe le code en tokens (erreurs en français : ligne + colonne) |
| 2. Parser | `parser.rs` | construit l'arbre syntaxique (classes, interfaces, match, try/catch, spawn…) |
| 3. Type Checker | `checker.rs` | vérifie les types, l'immuabilité, les contrats d'interfaces — **c'est ici que vit le borrow checker simplifié** |
| 4. Code Generator | `codegen.rs` | traduit l'arbre en **C**, avec un runtime maison (`src/runtime.h`) |

Puis **gcc** produit le binaire natif : `Lexer → Parser → Type Checker → Code Generator (C) → gcc`.

## Installer et utiliser

Prérequis : Rust (rustc ≥ 1.70) et gcc/clang.

```bash
cd rustava
cargo build --release
# le compilateur : target/release/rustava

./target/release/rustava run   exemples/nexus.rv   # compile et exécute
./target/release/rustava build exemples/nexus.rv   # produit le binaire « nexus »
./target/release/rustava check exemples/nexus.rv   # vérifie sans rien produire
./target/release/rustava c     exemples/nexus.rv   # montre le C généré
```

## Les exemples (dossier `exemples/`)

| Fichier | Ce qu'il montre |
| - | - |
| `nexus.rv` | **l'exemple exact du créateur** (Aissa, 30 → 31) |
| `test-mariage.rv` | chaque règle de la table : var, let, try/catch, match, for, tableaux, chaînes, spawn, horloge |
| `animaux.rv` | le polymorphisme : `Chien implements Animal`, dispatch dynamique natif |
| `tri.rv` | un vrai programme : le tri à bulles |
| `concurrent.rv` | 8 threads légers qui courent en même temps (sorties dans le désordre — preuve de vraie concurrence) |

## Les messages d'erreur — en français, avec ligne et cause

```
Erreur de type (ligne 3) : « x » est immuable (déclaré avec let) : impossible de la modifier — utilise var si tu veux la changer
Erreur de syntaxe (ligne 5) : Rustava refuse l'héritage (« extends ») : compose avec des interfaces (implements) — c'est le mariage choisi
Erreur de type (ligne 5) : la classe « Chien » dit « implements Animal » mais la méthode « crier » manque (contrat incomplet)
Erreur de type (ligne 3) : je ne connais pas « x » dans ce contexte
```

Et le cas inverse, le mariage qui accepte : passer un `Chien` là où un `Animal` (interface) est attendu — accepté, car un Chien **EST** un Animal.

## La suite de tests

```bash
bash tests/regression.sh
# === TOUS LES TESTS PASSENT ===
```

9 vérifications : l'exemple Nexus, le contrat complet, le polymorphisme, le tri, les threads, **et les 4 refus** (extends, let modifié, contrat incomplet, affectation dans un if).

## Ce que Rustava ne fait pas (encore)

- pas de `extends` — c'est un choix, pas un oubli (le mariage a tranché) ;
- `spawn` sur des méthodes de classe : refusé (les threads ne touchent pas aux champs d'une instance) ; spawn accepte 0 ou 1 argument simple ;
- l'arène a une capacité maximale (262 144 allocations par programme) ;
- pas de fermetures, pas de génériques — le mariage tient en trois mots : **simple, sûr, natif**.
