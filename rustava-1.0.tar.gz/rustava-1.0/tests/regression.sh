#!/usr/bin/env bash
# RUSTAVA — suite de non-régression
# Marche PARTOUT : avec le binaire livré (./rustava, à la racine)
# comme avec un arbre de développement (target/release/rustava).
set -u
DIR=$(cd "$(dirname "$0")/.." && pwd)   # racine du projet

# --- où est le compilateur ? ---
if [[ -x "$DIR/rustava" ]] ; then
    RV="$DIR/rustava"
elif [[ -x "$DIR/target/release/rustava" ]] ; then
    RV="$DIR/target/release/rustava"
else
    echo "[KO] le compilateur rustava est introuvable"
    echo "     (ni $DIR/rustava ni $DIR/target/release/rustava)"
    exit 1
fi
NEG="$DIR/tests/negatifs"

ECHEC=0

attend() { # attend fichier "sortie attendue" "description"
    local f="$1" attendu="$2" desc="$3" sortie code
    sortie=$("$RV" run "$f" 2>&1)
    code=$?
    if [[ $code -ne 0 ]] ; then
        echo "[KO] $desc (code $code)"
        ECHEC=$((ECHEC+1))
        return
    fi
    if [[ "$sortie" != *"$attendu"* ]] ; then
        echo "[KO] $desc (attendu « $attendu », reçu : ${sortie//$'\n'/ ; })"
        ECHEC=$((ECHEC+1))
        return
    fi
    echo "[OK] $desc"
}

refuse() { # refuse fichier "fragment du message" "description"
    local f="$1" fragment="$2" desc="$3" sortie code
    sortie=$("$RV" check "$f" 2>&1)
    code=$?
    if [[ $code -eq 0 ]] ; then
        echo "[KO] $desc (le compilateur aurait dû refuser)"
        ECHEC=$((ECHEC+1))
        return
    fi
    if [[ "$sortie" != *"$fragment"* ]] ; then
        echo "[KO] $desc (message inattendu : $sortie)"
        ECHEC=$((ECHEC+1))
        return
    fi
    echo "[OK] $desc"
}

echo "=== RUSTAVA — non-régression ==="
attend "$DIR/exemples/nexus.rv"        "Aissa"                  "l'exemple Nexus exact de l'utilisateur"
attend "$DIR/exemples/test-mariage.rv" "5050"                   "le contrat complet du mariage"
attend "$DIR/exemples/animaux.rv"      "miaou"                  "interfaces + dispatch dynamique"
attend "$DIR/exemples/tri.rv"          "1, 2, 3, 5, 7, 8, 9"    "le tri à bulles"
attend "$DIR/exemples/concurrent.rv"  "tous les threads ont fini" "spawn : threads légers"
attend "$DIR/exemples/demo-complete.rv" "thread léger lancé"     "la démonstration complète de la spécification"

refuse "$NEG/refuse-extends.rv"    "refuse l'héritage"  "extends est refusé (compositions only)"
refuse "$NEG/refuse-let.rv"        "est immuable"        "modifier un let est refusé"
refuse "$NEG/refuse-incomplet.rv" "contrat incomplet"   "interface incomplète est refusée"
refuse "$NEG/refuse-affect.rv"     "attendais"           "affectation dans un if est refusée"

# --- nettoyage des artéfacts produits par run (.c et binaires) ---
rm -f "$DIR"/exemples/*.c "$DIR"/exemples/spec/*.c \
      "$DIR"/exemples/nexus "$DIR"/exemples/test-mariage \
      "$DIR"/exemples/animaux "$DIR"/exemples/tri "$DIR"/exemples/concurrent \
      "$DIR"/exemples/demo-complete

if [[ $ECHEC -eq 0 ]] ; then
    echo "=== TOUS LES TESTS PASSENT ==="
else
    echo "=== $ECHEC ÉCHEC(S) ==="
    exit 1
fi
